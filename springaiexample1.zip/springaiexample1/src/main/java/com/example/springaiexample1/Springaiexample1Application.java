package com.example.springaiexample1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springaiexample1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springaiexample1Application.class, args);
	}

}
