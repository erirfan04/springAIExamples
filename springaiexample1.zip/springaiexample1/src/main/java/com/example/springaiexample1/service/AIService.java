package com.example.springaiexample1.service;

import com.example.springaiexample1.dto.CarDetail;
import org.springframework.ai.client.AiClient;
import org.springframework.ai.client.AiResponse;
import org.springframework.ai.parser.BeanOutputParser;
import org.springframework.ai.prompt.PromptTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AIService {

    @Autowired
    AiClient aiClient;

    public String getInfo(String topic){
        PromptTemplate promptTemplate = new PromptTemplate("""
                Please act as a Software developer and  tell me about the {topic}?
                give some example as well.
               """);
        promptTemplate.add("topic", topic);
        return this.aiClient.generate(promptTemplate.create()).getGeneration().getText();
    }

    // generate output in the JSON format via Prompting
    public String getCars(String category, String year){
        PromptTemplate promptTemplate = new PromptTemplate("""
                Please recommend the best car model for the given {category} (e.g., SUV, Sedan) and the {year}.
                Also provide a short review of the car — keep it concise, not too detailed.
                Please share the information in JSON format containing: category, car, year, review, manufacturer, summary.
                """);
         promptTemplate.add("category", category);
         promptTemplate.add("year", year);
         AiResponse generate = this.aiClient.generate(promptTemplate.create());
         return generate.getGeneration().getText();
    }

    // generate output in JSON format via mapping it to Dto
    public CarDetail getCarsInJson(String category, String year){
        BeanOutputParser<CarDetail> carBeanOutputParser = new BeanOutputParser<>(CarDetail.class);
        PromptTemplate promptTemplate = new PromptTemplate("""
                 Please recommend the best car model for the given {category} (e.g., SUV, Sedan) and the {year}.
                Also provide a short review of the car — keep it concise, not too detailed.
                Please share the information in JSON format containing: category, car, year, review, manufacturer, summary.
                {format}
                """);
        promptTemplate.add("category", category);
        promptTemplate.add("year", year);
        promptTemplate.add("format", carBeanOutputParser.getFormat());
        promptTemplate.setOutputParser(carBeanOutputParser);

        AiResponse response = aiClient.generate(promptTemplate.create());
        return carBeanOutputParser.parse(response.getGeneration().getText());

    }
}