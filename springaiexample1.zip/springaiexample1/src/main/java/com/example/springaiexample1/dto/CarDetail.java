package com.example.springaiexample1.dto;

public record CarDetail(
    String category,
    String carName,
    String year,
    String review,
    String manufacturer,
    String summary
) {};

