package com.example.springaiexample1.controller;

import com.example.springaiexample1.dto.CarDetail;
import com.example.springaiexample1.service.AIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/springai/api")
public class AIController {

    @Autowired
    AIService aiService;

    @GetMapping("/msg")
    public String getMsg(@RequestParam String topic){
        return aiService.getInfo(topic);
    }

    @GetMapping("/cars")
    public String getCars(@RequestParam String category, @RequestParam String year){
        return aiService.getCars(category, year);
    }

    @GetMapping("/carsInJSON")
    public CarDetail getBooksInJSON(@RequestParam String category, @RequestParam String year){
        return aiService.getCarsInJson(category, year);
    }
}